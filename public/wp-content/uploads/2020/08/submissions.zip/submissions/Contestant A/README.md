<h1>Insanely Scalable Server Example</h1>
<p>The point of this repo is to serve as a highly scalable NodeJS request server example</p>
<p>The program should be implemented using raw Node.js APIs with zero dependencies.</p>
<p>The client and the server must communicate together using JSON. Meaning, the client will send its request to the server in JSON, and the server must respond back in JSON.</p>
<p>In server-mode, it launches multiple child processes, across which tasks will be mapped, and each child will return the result of completing its task to the parent process, and the parent process in turn will reply back to the client with the answer.</p>
<p>In client-mode, the command reads a text file that contains lines of numbers. For each line, the client sends the list of numbers to the server to distribute to a child process for processing. To keep things simple, by default the utility will simply calculate the sum of the numbers.</p>
<p>The API for mapreduce looks like this:</p>
<h2>Example Usage</h2>
<code>$ node mapreduce.js --server --port=8000 --children=5</code>
<br>
<br>
<p>This tells the program to run in server mode (on port 8000), and to spawn 5 child processes across which it will split up work to be done. If an existing server process is already running, it should fail with an error. A possible idea for extra credit is being able to specify a different port to listen on.</p>
<p>Note: running the --server command will not put the program into the background. Meaning, you will have to open up a second terminal to run the client program (described next). To quit the server program (and all of its child processes), the users should simply be able to press Control-C in the terminal (^C).</p>
<code>$ node mapreduce.js --client --port=8000 --input=./arrays.txt</code>
<br>
<br>
<p>This tells mapreduce to run in client mode (on port 8000), read the file arrays.txt, and send to the server process a list of tasks to complete. In this case, those tasks will be to map the + operator across the numbers it read, and return the sum for each line in the file.</p>
<p>So for example, our file arrays.txt might look like this:</p>
<code>1 2 4 5 3 2 424 4</code>
<br>
<code>1, 3, 4, 6, 6, 8, 2, 0</code>
<br>
<code>2 22 434 323 2</code>
<br>
<br>
<p>In which case, it would send 3 tasks to be completed to the server process, each task representing a request to compute the sum of the list of numbers (each list representing one of those lines).</p>
<p>Notice: lines can use commas and/or spaces to separate numbers. Any other characters should result in an immediate error and abort of the program.</p>
<p>If the above was our input, the output should look like this:</p>
<code>$ node mapreduce.js --client --input=./arrays.txt</code>
<br>
<code>Array 1: 445</code>
<br>
<code>Ararry 2: 30</code>
<br>
<code>Array 3: 783</code>
<br>
<code>Total: 1258</code>
<br>
<br>
<p>If we want to do a load test of the server, we can specify the dimensions of the numbers array sent to the server:</p>
<code>$ node mapreduce.js --client --dimensions=10x10</code> 
<br>
<code>Array 1: 1204</code>
<br>
<code>Array 2: 1196</code>
<br>
<code>Array 3: 1211</code>
<br>
<code>Array 4: 1297</code>
<br>
<code>Array 5: 1149</code>
<br>
<code>Array 6: 1221</code>
<br>
<code>Array 7: 1550</code>
<br>
<code>Array 8: 1118</code>
<br>
<code>Array 9: 1318</code>
<br>
<code>Array 10: 1468</code>
<br>
<code>Total: 12732</code>
<br>
<br>
<p>The dimensions parameter is simply two integers deliminated by an "x". The dimensions MxN are used to create a query of N lines of M numbers each.</p>
<p>If the file contains more lines than child processes, work should still be distributed across all of them as evenly as possible.</p>
<h2>JSON Protocol</h2>
<p>The client and server communicate with a very simple JSON format.</p>
<p>Each input line is formatted into a JSON object and stringified before being sent over a single connection to the server:</p>
<code>'{"task":[1, 2, 3, ... n]}'</code> 
<br>
<br>
<p>For each connection (each line of numbers), a sum is returned in the form of a promise. Once all the connections complete, the result is printed, and summed.</p>
<p>The server sends the result for each line in the following JSON formatted string:</p>
<code>'{"result":123}'</code> 
<br>
<h2>Load Test Experiments</h2>
<p>First, to show that the code works, we did a small load test of the server:</p>
<code>node .\mapreduce.js --client --dimensions=12000x12000</code> 
<br>
<br>
<img src="./loadtest1.png">
<p>As you can see, the third logical processor of the first row handles the client processing. When the arrays reach the server, they are split up among the logical processors equally.</p>
<p>After the first load test, we tried a second load test that exceeded our memory:</p>
<code>node .\mapreduce.js --client --dimensions=12800x12800</code> 
<br>
<br>
<img src="./loadtest2.png">
<p>The major problem with our program is that it does not compress the JSON arrays into a binary format and uses strings instead. As can be seen from the above examples, trying to load test this server beyond a certain amount of CPU load causes a memory error</p>
<p>A highly recommended fix is to compress the JSON message using protocol buffers (I did not have enough time to do this ><).</p>
<h2>Useful Links:</h2>
<h3>Background Knlowedgle</h3>
<ul>
<li>https://docs.npmjs.com/creating-node-js-modules</li>
<li>https://nodejs.org/en/knowledge/command-line/how-to-parse-command-line-arguments/</li>
<li>https://nodejs.org/en/knowledge/file-system/how-to-read-files-in-nodejs/</li>
<li>https://gist.github.com/tedmiston/5935757</li>
<li>https://blog.logrocket.com/node-js-multithreading-what-are-worker-threads-and-why-do-they-matter-48ab102f8b10/</li>
</ul>
<h3>Heavy Code Borrowing:</h3>
<ul>
<li>https://www.sitepoint.com/how-to-create-a-node-js-cluster-for-speeding-up-your-apps/</li>
<li>https://stackoverflow.com/questions/42440537/node-7-6-async-await-issues-with-returning-data</li>
</ul>
