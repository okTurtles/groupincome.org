/*
Because we can't use any dependencies, we will spend a few lines on
writing a function for retreiving query parameter/values.
*/
var cliargs = process.argv.slice(2);
function parameterPresent(param_string){
    for(var i = 0; i < cliargs.length; i++)
        if(cliargs[i].indexOf(param_string)==0)
            return true;
    return false;
}
function parameterValue(param_string){
    for(var i = 0; i < cliargs.length; i++)
        if(cliargs[i].indexOf(param_string) == 0)
            return cliargs[i].split("=")[1]
    return false;
}

//The following function is a utility function for validating the input file.
//The input file contains lines of numbers, deliminated by commas and spaces.
function validate_digit(digit){
    switch(digit){
        case '0':
            return true;
        case '1':
            return true;
        case '2':
            return true;
        case '3':
            return true;
        case '4':
            return true;
        case '5':
            return true;
        case '6':
            return true;
        case '7':
            return true;
        case '8':
            return true;
        case '9':
            return true;
        // case '.'://No floating point values.
        //     return true;
        case '-':
            return true;
    }
}

//Both the client and server use the following NodeJS module.
//Might as well require it here:
const net = require('net');

//Same for the port:
var port = parameterPresent("--port") ? parseInt(parameterValue("--port")) : 8000;

//Server code:
if(parameterPresent("--server")){
    //We will use clusters to spawn the child processes.
    var cluster = require('cluster');

    if(cluster.isMaster) {

        //As-per specifications:
        cluster.schedulingPolicy = cluster.SCHED_RR;
        
        //Obtain the child count from the parameter list.
        var child_count = parseInt(parameterValue("--children"))
    
        //If the parameter list did not specify the number of children, then use the CPU count.
        if(!child_count){
            var cpus = require('os').cpus().length;
            console.log("Child count not specified. Using CPU count: "+cpus)
            child_count = cpus;
        }

        //Start the server cluster master process:
        var numWorkers = child_count;
    
        console.log('Master cluster setting up ' + numWorkers + ' workers...');
        
        for(var i = 0; i < numWorkers; i++) {
            cluster.fork();
        }
    
        cluster.on('online', function(worker) {
            console.log('Worker ' + worker.process.pid + ' is online');
        });
    
        cluster.on('exit', function(worker, code, signal) {
            console.log('Worker ' + worker.process.pid + ' died with code: ' + code + ', and signal: ' + signal);
            console.log('Starting a new worker');
            cluster.fork();
        });
    } 
    else {
        //Start a server child/cluster process:
        var server = net.createServer(function(socket) {
            socket.on('data', function(data){
                try{
                    var textChunk = data.toString('utf8');
                    var task_obj = JSON.parse(textChunk);
                    var sum = 0;
                    for(var i = 0; i < task_obj.task.length; i++)
                        sum+=task_obj.task[i];
                    socket.write(JSON.stringify({result:sum}));
                    socket.destroy();

                }
                catch(e)
                {
                    console.log(e);
                }
            }.bind(socket));
        });

        server.listen(port, '127.0.0.1');
    }
}

//Client code:
else if(parameterPresent('--client')){

    //We need to read the input file, so require the 'fs' module here:
    const fs = require('fs');

    var array_file = parameterValue("--input");
    var dimensions = parameterValue("--dimensions");
    var split_dims_string = [0, 0];
    var split_dims = [0, 0];
    
    if(dimensions){
        split_dims_string = dimensions.toLowerCase().split("x");
        split_dims = [parseInt(split_dims_string[0]), parseInt(split_dims_string[1])];
    }

    if(!array_file && (!split_dims[0] || !split_dims[1]))
    {
        console.log(`You must specify valid query dimensions, or an input file, for client mode.
Example usage:
$ node mapreduce.js --cllient --array=./arrays.txt
$ node mapreduce.js --client --dimensions=10x10`);
        return;
    }

    var final_numbers = []
    //If load-testing dimensions ARE given, then generate a random query:
    if(split_dims[0] && split_dims[1])
    {
        // console.log("Random array:");
        var total_sum = 0;
        for(var i = 0; i < split_dims[1]; i++)
        {
            var sum = 0;
            var line = (i==0?"[[":"[");
            final_numbers.push([]);
            for(var j = 0; j < split_dims[0]; j++)
            {
                var r = Math.floor(Math.random()*256.0);
                final_numbers[i].push(r);
                sum += r;
                line += r+(j!=split_dims[0]-1?",":"]");
            }
            // console.log(line+(i!=split_dims[1]-1?",":"]"));
            total_sum += sum;
        }
        // console.log("\n");
    }
    //If load-testing dimensions are NOT given, then try to read the file contents:
    else
    {
        var file_contents = fs.readFileSync(array_file, 'utf8')
    
        //Parse the numbers lists file:
        var task_lists = file_contents.split("\n");
        for(var i = 0; i < task_lists.length; i++){
            var cur_num = ""
            var started = false;
            final_numbers.push([]);
            for(var j = 0; j < task_lists[i].length; j++)
            {
                var letter = task_lists[i][j];
                if(validate_digit(letter))
                {
                    if(!started)
                    {
                        started = true;
                        cur_num = "";
                    }
                    cur_num += letter;
                }   
                else if(started)
                {
                    final_numbers[i].push(parseFloat(cur_num));
                    started = false;
                }
            }
            if(started)
                final_numbers[i].push(parseFloat(cur_num));
        }
    }
    
    //Utility function for creating a Promise for each server request:
    async function callServer(formattedJson) {
        return new Promise((resolve, reject) => {
            let client = new net.Socket()
    
            client.connect(port, '127.0.0.1', () => {
                client.write(formattedJson)
            })
    
            client.on('data', (data) => {
                var textChunk = data.toString('utf8');
                resolve(textChunk);
                client.destroy()
            })
    
            client.on('close', () => {
            })
    
            client.on('error', reject);
        });
    }

    //Send queries:
    var query_promises = [];
    for(var i = 0; i < final_numbers.length; i++)
    {
        var task_message = JSON.stringify({task:final_numbers[i]});
        query_promises.push(callServer(task_message))
    }

    //Wait for all the queries/Promises to resolve, or else throw an error:
    Promise.all(query_promises).then((values)=>{
        var total = 0;
        for(var i = 0; i < values.length; i++){
            var value = JSON.parse(values[i]).result;
            console.log("Array "+(i+1)+": "+value);
            total += value;
        }
        console.log("Total: "+total);
    }).catch((e)=>{
        console.log("Error! Client Promise rejected: "+e);
    });
}
else
{
    console.log(`Example usages:
$ node mapreduce.js --server
$ node mapreduce.js --server --port=8000 --children=5
$ node mapreduce.js --client --input=./arrays.txt
$ node mapreduce.js --client --port=8000 --dimensions=10x10`);
}