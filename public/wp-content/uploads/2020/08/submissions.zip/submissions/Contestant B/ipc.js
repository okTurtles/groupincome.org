const events = require('events');

function open(comm, handlers) {
  const idBank = {};
  const replyEm = new events.EventEmitter();

  comm.onMessage(msg => {
    if (msg.action === '__response') {
      delete idBank[msg.id];
      replyEm.emit(msg.id, msg.data);
    }
    else {
      const reply = (response) => {
        comm.send({
          id: msg.id,
          action: '__response',
          data: response,
        });
      };

      const handler = handlers[msg.action];
      if (handler) {
        handler(msg.data).then(response => {
          reply(response);
        });
      }
      else {
        console.error("Unhandled message:", msg);
        reply(null);
      }
    }
  });

  return (action, data) => {
    let id = 1;
    while (idBank[id]) id++;
    idBank[id] = true;

    comm.send({ id, action, data });

    return new Promise(resolve => {
      replyEm.once(id, data => {
        resolve(data);
      });
    });
  };
}

class TcpComm {

  constructor(socket) {
    this.socket = socket;
  }

  onMessage(callback) {
    let buf = '';

    this.socket.on('data', data => {
      buf += data.toString('utf-8');

      let splitAt;
      while ((splitAt = buf.indexOf('\n')) !== -1) {
        const msg = JSON.parse(buf.substring(0, splitAt));
        buf = buf.substring(splitAt + 1);
        callback(msg);
      }
    });
  }

  send(msg) {
    this.socket.write(JSON.stringify(msg) + '\n');
  }

}

class IpcComm {

  constructor(proc) {
    this.proc = proc;
  }

  onMessage(fn) {
    this.proc.on('message', fn);
  }

  send(msg) {
    this.proc.send(msg);
  }

}

module.exports = {
  open,
  TcpComm,
  IpcComm,
};
