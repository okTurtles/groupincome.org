# mapreduce

## Instructions

Starting a server:

    $ mapreduce --server 5

Using the client:

    $ mapreduce --client ./arrays.txt
    Array 1: 445
    Array 2: 30
    Array 3: 783
    Total: 1258

## Protocol

Overview:

1. Every message is minified JSON delimited by a single newline (`\n`) character.
2. Every JSON request message contains three keys:
   * `id: number` to identify the request/response.
   * `action: string` to identify the action to take.
   * `data: any` containing the actual payload.
3. Every message is responded to, even if its data is null.
4. This protocol works the same in both directions.
5. The "action" key may never start with double-underscores (`"__"`).
6. Every JSON response has the same ID as the request it's responding to.
7. This document uses `work: req-type -> resp-type` to mean:
   * Request's `action` key is "work"
   * Request's `data` key has the given type
   * Response's `data` key has the given type

Client -> Server:

* `sum: number[] -> number`
* `mul: number[] -> number`
* `avg: number[] -> number`

Server -> Child:

* (Identical to above.)
