const fs = require('fs');
const net = require('net');
const events = require('events');
const ipc = require('./ipc');


// We could change these to allow for floating points, etc.
const VALID_LINE = /^[ ,0-9]*$/;
const EXTRACT_NUMBERS = /[0-9]+/g;


async function runClient({ port, path, timeout, op: operation }) {
  // Parse file first to fail early if needed
  const groups = getNumberLines(path);

  let client = new Client(port);
  try {
    await client.ready(timeout);
  }
  catch (e) {
    console.error("Connecting to server timed out.");
    process.exit(1);
  }

  // Let them resolve in any order to get results faster
  const results = await Promise.all(groups.map(array =>
    client.send(operation, array)
  ));

  client.disconnect();

  let total = 0;
  results.forEach((n, i) => {
    total += n;
    console.log(`Array ${i + 1}: ${n}`);
  });
  console.log(`Total: ${total}`);
}


// This client *could* be inlined, but runClient reads nicer if it isn't.
class Client {

  constructor(port) {
    this.em = new events.EventEmitter();
    this.server = net.createConnection(port, () => {
      this.em.emit('ready');
    });

    this.send = ipc.open(new ipc.TcpComm(this.server), {
      // Currently the server never talks to us except to reply.
      // But if they did initiate messages, we'd handle it here.
    });

    this.server.on('error', err => {
      if (err.code === 'ECONNREFUSED') {
        console.error('Server unavailable. Make sure the server is running and the port is correct.');
        process.exit(1);
      }

      console.error(err);
    });

    this.server.on('end', data => {
      console.error('Server disconnected!');
      process.exit(1);
    });
  }

  ready(timeoutSec) {
    return new Promise((resolve, reject) => {
      let timeout;
      if (timeoutSec) {
        timeout = setTimeout(reject, timeoutSec * 1000);
      }

      this.em.once('ready', () => {
        if (timeout) clearTimeout(timeout);
        resolve();
      });
    });
  }

  disconnect() {
    this.server.destroy();
  }
}


function getNumberLines(path) {
  const contents = fs.readFileSync(path, 'utf-8');
  const lines = contents.split(/[\r\n]/g);

  const invalidLine = lines.find(line => !line.match(VALID_LINE));
  if (invalidLine) {
    console.error(`Invalid line: ${invalidLine}`);
    process.exit(3);
  }

  return (lines
    .map(parseLine)
    .filter(group => group.length > 0));
}


function parseLine(line) {
  return [...line.matchAll(EXTRACT_NUMBERS)].map(([m]) => parseInt(m));
}


module.exports = {
  runClient,
};
