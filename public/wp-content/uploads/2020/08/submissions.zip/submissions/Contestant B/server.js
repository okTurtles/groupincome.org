const net = require('net');
const events = require('events');
const child_process = require('child_process');
const ipc = require('./ipc');
const { sleep } = require('./util');


async function runServer({ port, count }) {
  const server = new Server(port);
  await server.ready();

  let i = 0;
  const children = new Balancer(repeat(count, () => new Child(++i)));

  const calculate = async (action, array) => {
    const child = await children.getFirstAvailable();
    children.rotate();
    return child.send(action, array);
  };

  server.onNewClient(client => {
    ipc.open(new ipc.TcpComm(client), {

      sum: async (array) => await calculate('sum', array),
      mul: async (array) => await calculate('mul', array),
      avg: async (array) => await calculate('avg', array),

    });
  });
}


class Balancer {

  constructor(array) {
    this.array = array;
  }

  async getFirstAvailable() {
    let tried = 0;
    while (this.array[0].busy) {
      console.log(`Skipping proc #${this.array[0].id}`);
      this.rotate();

      tried++;
      if (tried === this.array.length) {
        tried = 0;
        await sleep(1);
        console.log("Tried all subprocs; waiting 1s before trying again.");
      }
    }
    return this.array[0];
  }

  rotate() {
    const item = this.array.shift();
    this.array.push(item);
    return item;
  }

}


class Server {

  constructor(port) {
    this.em = new events.EventEmitter();

    this.server = net.createServer(client => {
      this.em.emit('new-client', client);
    });

    this.server.on('error', err => {
      if (err.code === 'EADDRINUSE') {
        console.error("Server already running on this port.");
        console.error("Try another port with the --port flag.");
        process.exit(2);
      }

      console.error(err);
      process.exit(2);
    });

    this.server.listen(port, () => {
      this.em.emit('ready');
    });
  }

  ready() {
    return new Promise(resolve => {
      this.em.once('ready', resolve);
    });
  }

  onNewClient(fn) {
    this.em.on('new-client', fn);
  }

}


class Child {

  constructor(id) {
    this.id = id;
    this.busy = false;
    this.proc = child_process.spawn(process.argv[1], [], {
      stdio: ['ignore', 'ignore', 'inherit', 'ipc'],
      env: {
        ...process.env,
        __MAPREDUCE_CHILD: '1',
      },
    });

    console.log(`Started proc #${this.id}`);

    this.proc.on('exit', (code, signal) => {
      // TODO: try to respawn it maybe?
      console.error('Child exited:', { code, signal });
    });

    const logBusiness = (state) => {
      console.log(`State of proc #${this.id} set = ${state}`);
    };

    const send = ipc.open(new ipc.IpcComm(this.proc), {
      busy: async () => { logBusiness('busy'); this.busy = true; },
      done: async () => { logBusiness('done'); this.busy = false; },
    });

    this.send = async (...args) => {
      console.log(`Sending to proc #${this.id}: ${JSON.stringify(args)}`);
      const result = await send(...args);
      console.log(`Got response from proc #${this.id}: ${JSON.stringify(result)}`);
      return result;
    };
  }

}


function repeat(count, fn) {
  return [...Array(count)].map(fn);
}


module.exports = {
  runServer,
};
