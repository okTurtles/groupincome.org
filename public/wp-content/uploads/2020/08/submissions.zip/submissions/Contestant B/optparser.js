const fs = require('fs');

function run(args, parameters, validate) {

  // Prepare help menu
  let help = [
    `Usage: ${process.argv[1]} [options]`,
    ...buildHelpLines([
      ['help', 'h', 'Show this help menu'],
      ...parameters,
    ])
  ].join('\n');

  const showHelp = () => {
    console.error(help);
    process.exit(0);
  };

  const options = {};

  // Setup default flags
  const flags = {
    '-h': showHelp,
    '--help': showHelp,
  };

  // Setup given flags
  for (const [long, short, desc, type, param, defaultValue] of parameters) {
    if (defaultValue) options[param] = defaultValue;

    const fn = (arg) => {
      options[long] = true;

      if (type) {
        const nextArg = args.shift();
        if (nextArg === undefined) {
          console.error(`Expected argument after ${arg}\n`);
          showHelp();
        }
        try {
          options[param] = type(nextArg);
        }
        catch (e) {
          console.error(`Error handling ${param}: ${e.message}\n`);
          showHelp();
        }
      }
    };

    flags[`--${long}`] = fn;
    flags[`-${short}`] = fn;
  }

  // Finally parse all args
  while (args.length > 0) {
    const arg = args.shift();

    const fn = flags[arg];
    if (!fn) {
      console.error(`Unknown option: ${arg}\n`);
      showHelp();
    }
    fn(arg);
  }

  if (!validate(options)) showHelp();

  return options;
}

// Slightly tedious calculations to align help menu nicely
function buildHelpLines(parameters) {
  let lines = parameters.map(([long, short, desc, type, param, defaultValue]) => {
    let firstHalf = `  -${short} --${long}`;
    if (param) firstHalf += ` <${param}>`;
    if (defaultValue) firstHalf += ` (${defaultValue})`;
    return [firstHalf, desc];
  });

  const alignHelpBy = lines.reduce(
    (len, [firstHalf, desc]) => Math.max(len, firstHalf.length),
    0
  );

  return lines.map(([firstHalf, desc]) =>
    [firstHalf.padEnd(alignHelpBy, ' '), desc].join('   ')
  );
}

function realFilePath(path) {
  if (!fs.existsSync(path) || !fs.lstatSync(path).isFile()) throw new Error('File expected');
  return path;
}

function realNumber(n) {
  n = parseInt(n);
  if (isNaN(n) || !isFinite(n)) throw new Error('Number expected');
  return n;
}

function oneOf(list) {
  return opt => {
    if (!list.includes(opt)) throw new Error('Expected one of: ' + list);
    return opt;
  };
}

module.exports = {
  run,
  realFilePath,
  realNumber,
  oneOf,
};
