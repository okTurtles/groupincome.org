/**
 * The idea for sending 'busy' / 'done' was to alert the parent
 * to when this child would be unavailable and again available
 * for work, so the parent can best distribute work equally to
 * whichever subprocs weren't busy. But in practice it doesn't
 * send it on time. For bigger loads it might be useful though.
 */

const ipc = require('./ipc');
const { sleep } = require('./util');

function runChild() {

  const send = ipc.open(new ipc.IpcComm(process), {

    sum: async (array) => withBusy(send, () => array.reduce((a, b) => a + b, 0)),
    mul: async (array) => withBusy(send, () => array.reduce((a, b) => a * b, 1)),
    avg: async (array) => withBusy(send, () => array.reduce((a, b) => a + b, 0) / array.length),

  });

}

async function withBusy(send, work) {
  await send('busy');
  const result = await work();
  // await sleep(3);
  await send('done');
  return result;
}

module.exports = {
  runChild,
};
